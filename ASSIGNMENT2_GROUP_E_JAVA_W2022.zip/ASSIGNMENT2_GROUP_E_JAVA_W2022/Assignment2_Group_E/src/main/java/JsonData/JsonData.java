package JsonData;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Servlet implementation class JsonData
 */
public class JsonData extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public JsonData() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("null")
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);

		response.setContentType("text/html");

		// PrintWriter writer = response.getWriter();
		// writer.println("<html>Avg is: " + "<html>");
		// writer.flush();

		PrintWriter writer = response.getWriter();
		JSONParser jsonparser = new JSONParser();

		FileReader reader = new FileReader(
				"C:\\Users\\Yamini Chirag Swami\\eclipse-workspace\\Assignment2_Group_E\\jsonFiles\\student.json");
		Object obj = null;
		try {
			obj = jsonparser.parse(reader);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JSONObject empJsonObj = (JSONObject) obj;

		String subject1, subject2, subject3, subject4, subject5;

		String collegename = (String) empJsonObj.get("collegename");
		String cityname = (String) empJsonObj.get("city");

		// writer.println("<html>College name is: " + collegename + "<br/><html>");
		// writer.println("<html>City name is: " + cityname + "<br/></html>");
		// writer.println("<html><br/></html>");
		// writer.flush();

		// Define objects
		JSONArray array1 = (JSONArray) empJsonObj.get("names");
		JSONArray array2 = (JSONArray) empJsonObj.get("address");
		JSONArray array3 = (JSONArray) empJsonObj.get("score");
		JSONArray array4 = (JSONArray) empJsonObj.get("phone");

		// Define Array
		String[] firstNameArray = { "", "", "", "", "" };
		String[] lastNameArray = { "", "", "", "", "" };

		String[] streetArray = { "", "", "", "", "" };
		String[] cityArray = { "", "", "", "", "" };
		String[] stateArray = { "", "", "", "", "" };

		Double[] avgArray = { 0.0, 0.0, 0.0, 0.0, 0.0 };

		String[] numberValueArray = { "", "", "", "", "" };

		// Fetch data from JSON file
		for (int i = 0; i < array1.size(); i++) {
			JSONObject details1 = (JSONObject) array1.get(i);
			JSONObject details2 = (JSONObject) array2.get(i);
			JSONObject details3 = (JSONObject) array3.get(i);
			JSONObject details4 = (JSONObject) array4.get(i);

			String firstName = (String) details1.get("firstName");
			String lastName = (String) details1.get("lastName");

			firstNameArray[i] = firstName;
			lastNameArray[i] = lastName;

			// writer.println("<html>First Name is: " + firstName + "<br/></html>");
			// writer.println("<html>Last Name is: " + lastName + "<br/></html>");
			// writer.flush();

			String street = (String) details2.get("street");
			String city = (String) details2.get("city");
			String state = (String) details2.get("state");

			streetArray[i] = street;
			cityArray[i] = city;
			stateArray[i] = state;

			// writer.println("<html>Street: " + street + "<br/></html>");
			// writer.println("<html>City: " + city + "<br/></html>");
			// writer.println("<html>State: " + state + "<br/></html>");

			subject1 = (String) details3.get("subject1");
			subject2 = (String) details3.get("subject2");
			subject3 = (String) details3.get("subject3");
			subject4 = (String) details3.get("subject4");
			subject5 = (String) details3.get("subject5");

			Double subject1Value = Double.parseDouble(subject1);
			Double subject2Value = Double.parseDouble(subject2);
			Double subject3Value = Double.parseDouble(subject3);
			Double subject4Value = Double.parseDouble(subject4);
			Double subject5Value = Double.parseDouble(subject5);

			Double avg = (subject1Value + subject2Value + subject3Value + subject4Value + subject5Value) / 5;

			avgArray[i] = avg;

			// writer.println("<html>Average is: " + avg + "<br/></html>");

			String numberValue = (String) details4.get("no");

			numberValueArray[i] = numberValue;

			// writer.println("<html>Phone number: " + numberValue + "<br/></html>");
			// writer.println("<html><br/></html>");
			// writer.println("<html><br/></html>");
		}

		String base = (String) empJsonObj.get("base");
		String height = (String) empJsonObj.get("height");
		String side = (String) empJsonObj.get("side");

		Integer baseInt = Integer.parseInt(base);
		Integer heightInt = Integer.parseInt(height);
		Integer sideInt = Integer.parseInt(side);

		Integer AreaOfTriangle = (baseInt * heightInt) / 2;
		Integer AreaOfSquare = sideInt * sideInt;

		// writer.println("<html>Area Of Triangle: " + AreaOfTriangle + "<br/></html>");
		// writer.println("<html>Area Of Square: " + AreaOfSquare + "<br/></html>");

		// Forwarding information to jsp file

		// Pass data from Servlet to JSP file using parameter attributes
		request.setAttribute("collegename", collegename);
		request.setAttribute("cityname", cityname);

		request.setAttribute("firstNameArray", firstNameArray);
		request.setAttribute("lastNameArray", lastNameArray);

		request.setAttribute("streetArray", streetArray);
		request.setAttribute("cityArray", cityArray);
		request.setAttribute("stateArray", stateArray);

		request.setAttribute("avgArray", avgArray);

		request.setAttribute("numberValueArray", numberValueArray);

		request.setAttribute("AreaOfTriangle", AreaOfTriangle);
		request.setAttribute("AreaOfSquare", AreaOfSquare);

		// Send data using request dispatcher
		request.getRequestDispatcher("Final.jsp").forward(request, response);
	}

}
